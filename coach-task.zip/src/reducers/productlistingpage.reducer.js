export function rootReducer(defStore = [], action) {
    switch (action.type) {
      case "FETCH_ALL_PRODUCTS":
        return action.products;
      default:
        return defStore;
    }
  }

export default rootReducer;  