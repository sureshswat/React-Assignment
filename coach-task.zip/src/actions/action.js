
export const FetchAllProducts = (products) => ({ type: "FETCH_ALL_PRODUCTS", products });
export const FETCH_ALL_PRODUCTS_ASYNC = (page) => ({ type: "FETCH_ALL_PRODUCTS_ASYNC", page });