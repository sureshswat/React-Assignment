import { takeLatest, put } from "redux-saga/effects";
import sitProducts from "./json/sit-products.json";
import bags from "./json/bags.json";
import news from "./json/new.json";
import women from "./json/women.json";
import men from "./json/men.json";
import coachReloved from "./json/coach-reloved.json";
import happyhoursale from "./json/happyhoursale.json";
import bundleAndSave from "./json/bundle-and-save.json";
import qaAutoCategory from "./json/qa-auto-category.json";


let getProductsList = (page) => {
    switch (page) {
        case "SIT-PRODUCTS":
          return sitProducts;
        case "BAGS":
            return bags;
        case "NEW":
          return news;
        case "WOMEN":
            return women;
        case "MEN":
          return men;
        case "COACH-RELOVED":
          return coachReloved;
        case "HAPPYHOURSALE":
          return happyhoursale;
        case "BUNDLE-AND-SAVE":
          return bundleAndSave;
        case "QA-AUTO-CATEGORY":
          return qaAutoCategory;
        default:
          return men;
    }
}

  
export function* fetchAllProductsAsync(pageType) {
    try {
        yield put({ type: "FETCH_ALL_PRODUCTS", products: getProductsList(pageType.page) });
    } catch (error) {
        console.log(error);
    }
}

// watcher
export function* mySaga() {
    yield takeLatest("FETCH_ALL_PRODUCTS_ASYNC", fetchAllProductsAsync);
}