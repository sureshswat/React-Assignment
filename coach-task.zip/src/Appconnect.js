import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as AllActions from "./actions/action";
import App from "./App";

// expose store data as props to react components
function mapStateToProps(store) {
  return {
    allProducts: store.products,
  };
}

// exposes action creators as props to react components
function mapDispatchToProps(dispatcher) {
  return bindActionCreators(AllActions, dispatcher);
}

var MainApp = connect(mapStateToProps, mapDispatchToProps)(App);
export default MainApp;
