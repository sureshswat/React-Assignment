import { applyMiddleware, createStore } from "redux";
import rootReducer from "./reducers/productlistingpage.reducer";
import createSagaMiddleware from "redux-saga";
import { mySaga } from "./Appsaga";

const sagaMiddleware = createSagaMiddleware();
let store = createStore(
  rootReducer,
  applyMiddleware(sagaMiddleware)
);
sagaMiddleware.run(mySaga);

export default store;