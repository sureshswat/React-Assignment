import { Routes, Route } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import MainLayout from "./components/layout/MainLayout";
import ProductListingPage from "./components/layout/PlpTemp";
import ProductDescriptionPage from "./components/layout/PdpTemp";
import HomePage from "./components/Home";

function App(props) {
  return (
      <MainLayout>
        <Routes>
          <Route path="/" element={<HomePage />}></Route>
          <Route path="/products/:id" element={<ProductDescriptionPage />}></Route>
          <Route path="/sit-products" element={<ProductListingPage />}></Route>
          <Route path="/bags" element={<ProductListingPage />}></Route>
          <Route path="/new" element={<ProductListingPage />}></Route>
          <Route path="/women" element={<ProductListingPage />}></Route>
          <Route path="/men" element={<ProductListingPage />}></Route>
          <Route path="/coach-reloved" element={<ProductListingPage />}></Route>
          <Route path="/happyhoursale" element={<ProductListingPage />}></Route>
          <Route path="/bundle-and-save" element={<ProductListingPage />}></Route>
          <Route path="/qa-auto-category" element={<ProductListingPage />}></Route>
        </Routes>
      </MainLayout>
  );
}

export default App;