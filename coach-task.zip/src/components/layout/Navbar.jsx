import React from "react";
import { Link } from "react-router-dom";
import { useDispatch } from 'react-redux'

export const Navbar = (props) => {
    const dispatch = useDispatch();

    const productListsPage = (page) => {
        let currentPage = page.getAttribute('href').toLocaleUpperCase().substring(1, page.getAttribute('href').length);
        dispatch({ type: "FETCH_ALL_PRODUCTS_ASYNC", page: currentPage });
    }

    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container-fluid">
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <Link to="/sit-products" className="nav-link" onClick={(e) => productListsPage(e.target)}>SIT PRODUCTS</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/bags" className="nav-link" onClick={(e) => productListsPage(e.target)}>BAGS</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/new" className="nav-link" onClick={(e) => productListsPage(e.target)}>NEW</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/women" className="nav-link" onClick={(e) => productListsPage(e.target)}>WOMEN</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/men" className="nav-link" onClick={(e) => productListsPage(e.target)}>MEN</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/coach-reloved" className="nav-link" onClick={(e) => productListsPage(e.target)}>COACH (RE)LOVED</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/happyhoursale" className="nav-link" onClick={(e) => productListsPage(e.target)}>HAPPYHOURSALE</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/bundle-and-save" className="nav-link" onClick={(e) => productListsPage(e.target)}>BUNDLE AND SAVE</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/qa-auto-category" className="nav-link" onClick={(e) => productListsPage(e.target)}>QA AUTO CATEGORY</Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    )
}

export default Navbar;