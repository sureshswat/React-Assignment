import React from "react";
import Navbar from "./Navbar";

export const MainLayout = (props) => {
    return (
        <div>
            <Navbar />
            <main className="container-fluid">
                {props.children}
            </main>
        </div>
    )
}

export default MainLayout;