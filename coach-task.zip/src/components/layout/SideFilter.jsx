import React from "react";

export const SideFilter = (props) => {
    const filterList = props.filters;
    
    return (
        <div>
            <div className="accordion" id="accordionFilter">
                {   
                filterList.map((list, index) => (
                    (list.displayName === "Price") || (list.value && list.value.length) ? 
                    <div key={index} className="accordion-item">
                        <h2 className="accordion-header" id={`${list.displayName.replace(/\s+/g, '').toLowerCase()}${index}`}>
                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target={`#${list.displayName.replace(/\s+/g, '').toLowerCase()}`} aria-expanded="false" aria-controls={list.displayName.replace(/\s+/g, '').toLowerCase()}>
                            {list.displayName}
                        </button>
                        </h2>
                        <div id={list.displayName.replace(/\s+/g, '').toLowerCase()} className="accordion-collapse collapse" aria-labelledby={`${list.displayName.replace(/\s+/g, '').toLowerCase()}${index}`} data-bs-parent="#accordionFilter">
                            <div className="accordion-body">
                                
                                {list.attributeID === 'colorVal' && list.value.length ?
                                <div className="row m-0 side-filter">  
                                    {
                                        list.value.map((color, index) => (
                                            <span key={index} className="color" style={{backgroundColor: color.swatchID}}></span>
                                        ))
                                    }
                                </div>
                                : ""}

                                {list.attributeID === 'onlineExclusive' && list.value.length ?
                                <div className="row m-0 side-exclusive">  
                                    {
                                        list.value.map((exclusive, index) => (
                                            <button key={index} type="button" className="btn btn-outline-secondary w-auto">{exclusive.refvalue}</button>
                                        ))
                                    }
                                </div>
                                : ""}
                                
                                {list.attributeID === 'filterCategory' && list.value.length ? 
                                    list.value.map((category, index) => (
                                        <div key={index} className="d-flex side-category"> 
                                        <input type="checkbox" className="side-category-checkbox" disabled={!category.selectable} />
                                        <h6 className="w-auto m-0 side-category-text">{category.refvalue}</h6>
                                        </div>
                                    ))
                                : ""}

                                {list.attributeID === 'bagSize' && list.value.length ?
                                <div className="row m-0 side-bagsize">  
                                    {
                                        list.value.map((size, index) => (
                                            <button key={index} type="button" className="btn bag-size btn-outline-secondary w-auto" disabled={!size.selectable}>{size.refvalue}</button>
                                        ))
                                    }
                                </div>
                                : ""}

                                {list.attributeID === 'gender' && list.value.length ?
                                <div className="row m-0 side-gender">  
                                    {
                                        list.value.map((gender, index) => (
                                            <button key={index} type="button" className="btn gender btn-outline-secondary w-auto" disabled={!gender.selectable}>{gender.refvalue}</button>
                                        ))
                                    }
                                </div>
                                : ""}

                                {list.attributeID === 'material' && list.value.length ?
                                <div className="row m-0 side-material">  
                                    {
                                        list.value.map((material, index) => (
                                            <button key={index} type="button" className="btn material btn-outline-secondary" disabled={!material.selectable}>{material.refvalue}</button>
                                        ))
                                    }
                                </div>
                                : ""}

                                {list.attributeID === 'heelHeightVal' && list.value.length ? 
                                    list.value.map((heel, index) => (
                                        <div key={index} className="d-flex side-heels"> 
                                        <input type="checkbox" className="side-heels-checkbox" disabled={!heel.selectable} />
                                        <h6 className="w-auto m-0 side-heels-text">{heel.refvalue}</h6>
                                        </div>
                                    ))
                                : ""}

                            </div>
                        </div>
                    </div> : ''
                ))
                }
            </div>
        </div>
    )
}

export default SideFilter;