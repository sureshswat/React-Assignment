import React, { useEffect, useState } from "react";

export const ProductImagePLP = (props) => {
    const pName = props.productName;
    const pImageList = props.schemeproduct;
    const [imageTag, setimageTag] = useState();

    useEffect(() => {
        let imageurl;
        if(pName && pImageList) {
            pImageList.filter((schemeproduct) => {
                if(schemeproduct.name.indexOf(pName) !== -1) {
                    imageurl = schemeproduct.image[0];
                }
                return false;
            })
        }
        if(imageurl) {
            setimageTag(imageurl);
        } else {
            setimageTag('https://images.coach.com/is/image/Coach/coach-brand-image?$$')
        }
    }, [pImageList, pName, imageTag])

    return (
        <img className="img-fluid" src={imageTag} alt={pName} />
    )
}

export default ProductImagePLP;