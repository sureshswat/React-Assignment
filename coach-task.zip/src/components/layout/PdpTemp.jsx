import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

import ProductImage from "./PlpImageTemp";

export const ProductDescriptionPage = (props) => {
    const location = useLocation();
    const productsDetails = location.state.productsDetails;
    const productImageList = location.state.schemeproduct;
    const [price, setprice] = useState();

    const updatePrice = (e) => {
        let newprice = e.parentNode.getAttribute('price') 
        setprice(newprice)
    }

    useEffect(() => {
        if(productsDetails) {
            document.querySelector('.long-description').innerHTML = productsDetails.longDescription;
            let promoCallOut = "";
            if(productsDetails.promotion[0].promoCallOut.length) {
                productsDetails.promotion[0].promoCallOut.map((promo) => (
                    promoCallOut = `${ promoCallOut} ${promo}`
                ));
                document.querySelector('.promo-callout').innerHTML = promoCallOut;
            }
        }
    }, [price])

    return (
        <div>
            <div className="row mt-2">
                <div className="col-3 col-md-1">
                    <figure>
                        <ProductImage productName = {productsDetails.name} schemeproduct = {productImageList}  />
                    </figure>
                </div>
                <div className="col-9 col-md-7">
                    <figure>
                        <ProductImage productName = {productsDetails.name} schemeproduct = {productImageList}  />
                    </figure>
                </div>
                <div className="col-12 col-md-4">
                    <h1>{productsDetails.name}</h1>
                    <h5>{price ? price : productsDetails.maxPrices}</h5>
                    <div className="promo-callout mt-3 mb-3"></div>
                    <div className="row">
                        {   
                            (productsDetails.variants && productsDetails.variants.length) ? 
                            productsDetails.variants.map((list, index) => (
                                list.ATS ?
                                <div key={index} className="col-4 col-md-3">
                                    <figure className="customPrice" price={list.price} onClick={(e) => updatePrice(e.target)}>
                                        <ProductImage productName = {productsDetails.name} schemeproduct = {productImageList} />
                                    </figure>
                                </div> : ""
                            )) : ""
                        }
                    </div>
                    <div className="accordion" id="accordiondescription">
                        <div className="accordion-item">
                            <h2 className="accordion-header" id="long-description">
                            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#longDescription" aria-expanded="false" aria-controls="longDescription">
                                Product Details
                            </button>
                            </h2>
                            <div id="longDescription" className="accordion-collapse collapse" aria-labelledby="long-description" data-bs-parent="#accordiondescription">
                            <div className="accordion-body long-description"></div>
                            </div>
                        </div>
                        <div className="accordion-item">
                            <h2 className="accordion-header" id="short-description">
                            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#shortDescription" aria-expanded="false" aria-controls="shortDescription">
                                Short Description
                            </button>
                            </h2>
                            <div id="shortDescription" className="accordion-collapse collapse" aria-labelledby="short-description" data-bs-parent="#accordiondescription">
                            <div className="accordion-body short-description">{productsDetails.shortDescription}</div>
                            </div>
                        </div>
                        <div className="accordion-item">
                            <h2 className="accordion-header" id="editor-description">
                            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#editorDescription" aria-expanded="false" aria-controls="editorDescription">
                                Editor's Notes
                            </button>
                            </h2>
                            <div id="editorDescription" className="accordion-collapse collapse" aria-labelledby="editor-description" data-bs-parent="#accordiondescription">
                            <div className="accordion-body editor-description">{productsDetails.c_editorsNoteDescription}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ProductDescriptionPage;