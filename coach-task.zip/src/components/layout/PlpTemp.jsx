import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from 'react-redux'
import { Link, useLocation } from "react-router-dom";

import SideFilter from "./SideFilter";
import ProductImage from "./PlpImageTemp";

export const ProductListingPage = (props) => {
    const location = useLocation();
    const dispatch = useDispatch();
    const [productList, setproductList] = useState();
    let productsListResponce = useSelector((state) => state);
    let filterList = productsListResponce.refinements;
    let productsList = productsListResponce.hits;
    let productsImageList = productsListResponce.schemaData;

    const getAllData = () => {
        let currentPage = location.pathname.toLocaleUpperCase().substring(1, location.pathname.length);
        dispatch({ type: "FETCH_ALL_PRODUCTS_ASYNC", page: currentPage });
        setproductList(productsListResponce);
    }

    const productSortFilter = (option) => {
        if(productsList && option !== "0") {
            let sortedProducts = productsList.sort((first, second) =>  { 
                let priceA = first.promotion[0].Pricing.map(pricing => pricing.type ? pricing.min.sales.value : pricing.sales.value)
                let priceB = second.promotion[0].Pricing.map(pricing => pricing.type ? pricing.min.sales.value : pricing.sales.value)
                return priceA - priceB;
            });
            let sortedProductsList = option === "1" ? sortedProducts : sortedProducts.reverse();
            setproductList(sortedProductsList);
        }
    }

    useEffect(() => {
        getAllData();
    }, [productList])

    return (
        <div>
            {productList ?
            <div className="product-list-page">
                <nav aria-label="breadcrumb">
                    <ol className="breadcrumb mt-3 mb-3">
                        <li className="breadcrumb-item active" aria-current="page">{productsListResponce.alternateH1Tag ? productsListResponce.alternateH1Tag : productsListResponce.CurrentPageMetaData.title}</li>
                    </ol>
                </nav>
                <div className="row"> 
                    <div className="col-sm-12 col-md-3">
                        <SideFilter filters = {filterList} />
                    </div>
                    <div className="col-sm-12 col-md-9 mt-2">
                        <div className="d-flex justify-content-end filter-right">
                            <select defaultValue={"0"} className="form-select form-select-md mb-3" aria-label=".form-select-lg example"
                                onChange={(e) => productSortFilter(e.target.value)} 
                            >
                                <option value="0">Most Relevent</option>
                                <option value="1">Price Low to High</option>
                                <option value="2">Price High to Low</option>
                            </select>
                        </div>
                        <div className="row">
                            {   
                            productsList.map((product, productIndex) => (
                                <div key={productIndex} className="col-6 col-md-3 pb-3 product-tile-container">
                                    <Link to={`/products/${product.productId}`} className="productLink" 
                                        state={{  
                                            productsDetails: product,
                                            schemeproduct: productsImageList.itemListElement && productsImageList.itemListElement.length ? productsImageList.itemListElement : ''
                                        }}
                                    >
                                    <figure>
                                        { 
                                            productsImageList.itemListElement && productsImageList.itemListElement.length ?
                                            <ProductImage productName = {product.name} schemeproduct = {productsImageList.itemListElement}  /> : 
                                            <img className="img-fluid" src="https://images.coach.com/is/image/Coach/coach-brand-image?$$" alt="COACH" />
                                        }
                                    </figure>
                                    </Link>
                                    <h6>{product.promotion[0].inStockMessage}</h6>
                                    <h5 className="product-title">{product.name}</h5>
                                    {
                                    product.promotion[0].promoCallOutPLP ?   
                                    product.promotion[0].promoCallOutPLP.map((promocallout, index) => (
                                        promocallout !== '<div></div>' ? 
                                        <p key={index} className="m-0">{promocallout.toUpperCase()}</p> : ""
                                    )) : ''
                                    }
                                    {
                                    product.promotion[0].Pricing.map((pricing, index) => (
                                        pricing.type ? 
                                        <h6 key={index}>{pricing.min.sales.formatted} - {pricing.max.sales.formatted}</h6> : 
                                        <h6 key={index}>{pricing.sales.formatted}</h6>
                                    ))
                                    }
                                </div>
                            ))
                            }
                        </div>
                    </div>
                </div>
            </div>
            : "loading" }
        </div>
    )
}

export default ProductListingPage;