import React from "react";

export const HomePage = (props) => {
    return (
        <div>
            Home
        </div>
    )
}

export default HomePage;